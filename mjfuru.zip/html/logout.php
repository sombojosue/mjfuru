 <?php 
     
    session_start(); 
    session_destroy();
    unset($_SESSION['user_mjfuru']);
    header("location: index.php");
     
    
    ?>
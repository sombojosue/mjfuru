<?php 
session_start(); 
//include db_config file
include_once('includes/db_config.php');

if(!isset($_SESSION['user_mjfuru'])){
  echo "
   <script>window.location = 'index.php';</script>
  ";
}

if ($_GET['q']) {
  $data = strval($_GET['q']);
  //echo var_dump($data);
}

?>    
  <!DOCTYPE html>
<html lang="fr">
  <head>
    <title>MJFuru Restaurant</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui.min.css">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
   <link rel="stylesheet" href="css/timepicker.css">
   <!-- Favicon -->
   <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
   <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.ico">
   <link rel="manifest" href="images/site.webmanifest">
    <!-- End of favicon -->
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Lobster+Two&family=Playball&display=swap" rel="stylesheet">
    <!-- fontawesome -->
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="css/lightbox.min.css">
<style type="text/css">
  .form-wrapper {
  background-color: #f6f6f6;
  background-image: -webkit-gradient(linear, left top, left bottom, from(#f6f6f6), to(#eae8e8));
  background-image: -webkit-linear-gradient(top, #f6f6f6, #eae8e8);
  background-image: -moz-linear-gradient(top, #f6f6f6, #eae8e8);
  background-image: -ms-linear-gradient(top, #f6f6f6, #eae8e8);
  background-image: -o-linear-gradient(top, #f6f6f6, #eae8e8);
  background-image: linear-gradient(top, #f6f6f6, #eae8e8);
  border-color: #dedede #bababa #aaa #bababa;
  border-style: solid;
  border-width: 1px;
  -webkit-border-radius: 10px;
  -moz-border-radius: 10px;
  border-radius: 10px;
  -webkit-box-shadow: 0 3px 3px rgba(255,255,255,.1), 0 3px 0 #bbb, 0 4px 0 #aaa, 0 5px 5px #444;
  -moz-box-shadow: 0 3px 3px rgba(255,255,255,.1), 0 3px 0 #bbb, 0 4px 0 #aaa, 0 5px 5px #444;
  box-shadow: 0 3px 3px rgba(255,255,255,.1), 0 3px 0 #bbb, 0 4px 0 #aaa, 0 5px 5px #444;
  margin: 15px auto;
  overflow: hidden;
  padding: 8px;
  width: 450px;
}

.form-wrapper #client {
  border: 1px solid #CCC;
  -webkit-box-shadow: 0 1px 1px #ddd inset, 0 1px 0 #FFF;
  -moz-box-shadow: 0 1px 1px #ddd inset, 0 1px 0 #FFF;
  box-shadow: 0 1px 1px #ddd inset, 0 1px 0 #FFF;
  -webkit-border-radius: 3px;
  -moz-border-radius: 3px;
  border-radius: 3px;
  color: #999;
  float: left;
  font: 16px Lucida Sans, Trebuchet MS, Tahoma, sans-serif;
  height: 42px;
  padding: 10px;
  width: 320px;
}

.form-wrapper #client:focus {
  border-color: #aaa;
  -webkit-box-shadow: 0 1px 1px #bbb inset;
  -moz-box-shadow: 0 1px 1px #bbb inset;
  box-shadow: 0 1px 1px #bbb inset;
  outline: 0;
}

.form-wrapper #client:-moz-placeholder,
.form-wrapper #client:-ms-input-placeholder,
.form-wrapper #client::-webkit-input-placeholder {
  color: #999;
  font-weight: normal;
}

.form-wrapper #submit {
  background-color: #0483a0;
  background-image: -webkit-gradient(linear, left top, left bottom, from(#31b2c3), to(#0483a0));
  background-image: -webkit-linear-gradient(top, #31b2c3, #0483a0);
  background-image: -moz-linear-gradient(top, #31b2c3, #0483a0);
  background-image: -ms-linear-gradient(top, #31b2c3, #0483a0);
  background-image: -o-linear-gradient(top, #31b2c3, #0483a0);
  background-image: linear-gradient(top, #31b2c3, #0483a0);
  border: 1px solid #00748f;
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  -webkit-box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset, 0 1px 0 #FFF;
  -moz-box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset, 0 1px 0 #FFF;
  box-shadow: 0 1px 0 rgba(255, 255, 255, 0.3) inset, 0 1px 0 #FFF;
  color: #fafafa;
  cursor: pointer;
  height: 42px;
  float: right;
  font: 15px Arial, Helvetica;
  padding: 0;
  text-transform: uppercase;
  text-shadow: 0 1px 0 rgba(0, 0 ,0, .3);
  width: 100px;
}

.form-wrapper #submit:hover,
.form-wrapper #submit:focus {
  background-color: #31b2c3;
  background-image: -webkit-gradient(linear, left top, left bottom, from(#0483a0), to(#31b2c3));
  background-image: -webkit-linear-gradient(top, #0483a0, #31b2c3);
  background-image: -moz-linear-gradient(top, #0483a0, #31b2c3);
  background-image: -ms-linear-gradient(top, #0483a0, #31b2c3);
  background-image: -o-linear-gradient(top, #0483a0, #31b2c3);
  background-image: linear-gradient(top, #0483a0, #31b2c3);
}

.form-wrapper #submit:active {
  -webkit-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.5) inset;
  -moz-box-shadow: 0 1px 4px rgba(0, 0, 0, 0.5) inset;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.5) inset;
  outline: 0;
}

.form-wrapper #submit::-moz-focus-inner {
  border: 0;
}
  @media (max-width: 576px) {

      #hide-mobile{
      display: none;
    }
    .form-wrapper{
  width: 90% !important;
  padding: 0 !important;
}
.form-wrapper #client{
  width: 80%;
  }
  .form-wrapper #submit{
  width: 20%;
  }
}
</style>
</head>
  <body>
    <div class="py-1 bg-black top">
      <div class="container">
        <div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
          <div class="col-lg-12 d-block">
            <div class="row d-flex">
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
                <span class="text">+ 243 999921710</span>
              </div>
              <div class="col-md pr-4 d-flex topper align-items-center">
                <div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
                <span class="text">mjfururestaurant@gmail.com</span>
              </div>
              <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
                <p class="mb-0 register-link"><span>Heures d'ouverture: </span><span>Lundi - Dimanche</span> <span>8 h 00 à 8 h 00</span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container">
        <a class="navbar-brand" href="index.php">MJFURU</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item" id="home"><a href="checktable.php?q=search" class="nav-link">Recherche</a></li>
            <li class="nav-item" id="menu"><a href="checktable.php?q=list" class="nav-link">Lists</a></li>
          <li class="nav-item" id="about"><a href="logout.php" class="nav-link">Se déconnecte</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- END nav -->

    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/table_01.jpg');" data-stellar-background-ratio="0.5" id="hide-mobile">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Réservation</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="checktable.php?q=search">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>
Réservation <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		<!-- Search bar inside the reservation page -->
    <?php if ($data === 'search') {?>
    <section class="ftco-section bg-light">
      <div class="container-fluid">
        <div class="row justify-content-center mb-5">
          <div class="col-xs-12 col-sm-12 col-md-12">
           <form class="form-wrapper" method="post" action="checktable.php?q=list">
           <input type="text" id="client" placeholder="Entrez le numéro" required name="phone">
          <input type="submit" value="go" id="submit" name="submit">
          </form> 
          </div>
        </div>
      </div>
    </section>
  <?php }?>
    <!-- End of search bar inside the reservation page -->
    <?php if ($data === 'list') {?>
    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <?php 
    //convert month into text
    $month = date("m");
    
    
    if ($month === "01") {
      $date = date('d')."-janv-".date('Y');
    }
    if ($month === "02") {
      $date = date('d')."-févr-".date('Y');
    }
    if ($month === "03") {
      $date = date('d')."-mars-".date('Y');
    }
    if ($month === "04") {
      $date = date('d')."-avr-".date('Y');
    }
    if ($month === "05") {
      $date = date('d')."-mai-".date('Y');
    }
    if ($month === "06") {
      $date = date('d')."-juin-".date('Y');
    }
    if ($month === "07") {
      $date = date('d')."-juil-".date('Y');
    }

    if ($month === "08") {
      $date = date('d')."-août-".date('Y');
    }
    if ($month === "09") {
      $date = date('d')."-sept-".date('Y');
    }

    if ($month === "10") {
      $date = date('d')."-oct-".date('Y');
    }
    if ($month === "11") {
      $date = date('d')."-nov-".date('Y');
    }
    if ($month === "12") {
      $date = date('d')."-déc-".date('Y');
    }

    if (isset($_POST['phone'])) {
      $search = $_POST['phone'];
      $sql_blog = "select name,date_book,heure_book,number_of_table from tbl_reservation where phone = '$search'  order by id asc limit 20";
    }else{
     $sql_blog = "select name,date_book,heure_book,number_of_table from tbl_reservation where date_book = '$date'  order by id asc limit 20";
    }
      $res_blog = mysqli_query($con, $sql_blog);
      if (mysqli_num_rows($res_blog) > 0) {?>
          <div class="col-md-12 text-center heading-section ftco-animate">
            <span class="subheading">Réservation</span>
            <h2 class="mb-4">Table réserver</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 ftco-animate">
            <div class="blog-entry">
          <table class="table table-hover">
            <tr>
              <th>Nom</th>
              <th>Date</th>
              <th>Heure</th>
              <th>Table</th>
            </tr>
      <?php 
      while ($row_blog = mysqli_fetch_assoc($res_blog)){?>
          
            <tr>
              <td><?php echo $row_blog['name'];?></td>
              <td><?php echo $row_blog['date_book'];?></td>
              <td><?php echo $row_blog['heure_book'];?></td>
              <td><?php echo "à ".$row_blog['number_of_table'];?></td>
            </tr>
            
          <?php }}?>
        </table>
          </div>
          </div>
        </div>
      </div>
    </section>
		<?php }?>
    <?php include_once('footer.php');?>


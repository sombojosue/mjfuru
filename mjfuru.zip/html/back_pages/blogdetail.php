<?php
session_start(); 
//include db_config file
include_once('includes/db_config.php');

//for whatsapp desciption only
 if (isset($_GET['display'])) {
  $search = $_GET['display'];
  $sql_pol = "select * from tbl_blog where blogid='$search'";
  $res_pol = mysqli_query($con, $sql_pol);
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
    $desc = $row_pol['title'];
    $desc_img = $row_pol['image'];
  }
 }
 else{
 	$desc = '';
 }
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <title>MJFuru Restaurant</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="mjfuru, restaurant,nourriture congolaise,place moderne" />
    <meta name="description" content="<?php echo $desc;?>" />
    <meta name="author" content="mjfuru" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">
   <!-- Favicon -->
   <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
   <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.ico">
   <link rel="manifest" href="images/site.webmanifest">
    <!-- End of favicon -->
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- fontawesome -->
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  </head>
  <body>
    <div class="py-1 bg-black top">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
	    		<div class="col-lg-12 d-block">
		    		<div class="row d-flex">
		    			<div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
						    <span class="text">+ 243819075554</span>
					    </div>
					    <div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
						    <span class="text">mjfururestaurant@gmail.com</span>
					    </div>
					    <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
						    <p class="mb-0 register-link"><span>Heures d'ouverture: </span><span>Lundi - Dimanche</span> <span>8 h 00 à 8 h 00</span></p>
					    </div>
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">MJFURU</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item" id="home"><a href="index.php" class="nav-link">Accueil</a></li>
	        	<li class="nav-item"><a href="https://app.mjfururestaurant.com" class="nav-link">Menu</a></li>
	        <li class="nav-item" id="about"><a href="about.php" class="nav-link">À propos</a></li>
	        	<li class="nav-item" id="contact"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="reservation.php" class="nav-link">Réserver une table</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
   
<!-- Checking if user click the link to read information -->
<?php
if (isset($_GET['display'])) {
  $search_blog = $_GET['display'];
  $sql_blog = "select title,image,message,date_blog,userid from tbl_blog where blogid='$search_blog'";
      $res_blog = mysqli_query($con, $sql_blog);
      while ($row_blog = mysqli_fetch_assoc($res_blog)){
      $title = $row_blog['title'];
      $image = $row_blog['image'];
      $message = $row_blog['message'];
      $date = $row_blog['date_blog'];
      $userid = $row_blog['userid'];
}
}
?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Blog</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Blog <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		<?php if ($_GET['display']) {?>
    <section class="ftco-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-md-9 col-lg-9 ftco-animate">
            <div class="blog-entry">
              <img src="<?php echo $image;?>" style="width: 100%;">
              <div class="text pt-3 pb-4 px-4">
                <div class="meta">

                <!-- Social network link -->
                <ul class='list-unstyled'>
                  <li><a href="https://www.facebook.com/sharer/sharer.php?u=<URL>&t=<TITLE>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on Facebook"><i class='fa fa-facebook' style='color:#3f5d9b;float: left;font-size: 24px;margin-right: 8px;'></i></a>
                  </li>
                  <li><a href="https://twitter.com/share?url=<URL>&text=<TITLE>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on Twitter"><i class='fa fa-twitter' style='color:#84b9d8;float: left;font-size: 24px;margin-right: 8px;'></i></a>
                  </li>
                  
                  <li><a href="whatsapp://send?text=<URL>" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on whatsapp"><i class='fa  fa-whatsapp text-success' style="float: left;font-size: 24px;margin-right: 8px;"></i></a>
                  </li>
                  
                </ul>
                <br>
                 <!-- End of social network -->
                  <div><a><?php echo $userid;?></a></div>
                </div>
                <h3 class="heading"><a><?php echo $title;?></a></h3>
                <p class="clearfix">
                  <?php echo $message;?>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  <?php }?>
    <!-- End of display blog detail information -->

	<section class="ftco-section bg-light" style="margin-top: -50px !important;">
			<div class="container">
				<div class="row">
      <?php 
      $sql_blog = "select title,image,date_blog,blogid,userid from tbl_blog order by blog_dis_date desc";
      $res_blog = mysqli_query($con, $sql_blog);
      while ($row_blog = mysqli_fetch_assoc($res_blog)){?>
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="blogdetail.php?display=<?php echo $row_blog['blogid'];?>" class="block-20" style="background-image: url(<?php echo $row_blog['image'];?>)">
              </a>
              <div class="text pt-3 pb-4 px-4">
                <div class="meta">
                  <div><a><?php echo $row_blog['date_blog'];?></a></div>

                  <div><a><?php echo $row_blog['userid'];?></a></div>
                </div>
                <h3 class="heading"><a href="blogdetail.php?display=<?php echo $row_blog['blogid'];?>"><?php echo $row_blog['title'];?></a></h3>
                <p class="clearfix">
                  <a href="blogdetail.php?display=<?php echo $row_blog['blogid'];?>" class="float-left read">Read more</a>
                </p>
              </div>
            </div>
          </div>
          <?php }?>
        </div>
			</div>
		</section>
		
    <?php include_once('footer.php');?>
<?php include_once('header.php');?>    
<!-- Checking if user click the link to read information -->
<?php
if (isset($_GET['pay'])) {
  $search_menu = $_GET['pay'];
  $sql_menu = "select title,image,detail,prix from tbl_food where foodid='$search_menu'";
      $res_menu = mysqli_query($con, $sql_menu);
      while ($row_menu = mysqli_fetch_assoc($res_menu)){
      $title_food = $row_menu['title'];
      $image_food = $row_menu['image'];
      $detail = $row_menu['detail'];
      $prix = $row_menu['prix'];
      
}
$timeTime = date('h');
if ($timeTime < 12) {
  $foodinfo = 'Diner';
}else{
  $foodinfo = 'Diner';
}
}else{
  header("location: index.php");
}
?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url(<?php echo $image_food;?>);background-size: cover;" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread"><?php echo $title_food;?></h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Accuel <i class="ion-ios-arrow-forward"></i></a></span> <span>Commande <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		<?php if ($_GET['pay']) {?>
    <section class="ftco-section" style="background-color: #eee;">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-md-9 col-lg-9 ftco-animate" style="background-color:white;border: 1px solid lightgray;margin:auto;">
            <div class="blog-entry form-group p-2 pl-3">
             <form method="post" action="" style="width: 85%;margin:auto;">
              <h2 class="subheading">Commandez votre <?php echo $foodinfo;?></h2>

            <!-- Error handler -->
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="errorBox">
            <strong id="errorMsg"></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>
            <!-- end of error -->
               <label for="name">Nom</label>
               <input type="text" name="name" id="name"  value="<?php echo $userlogin;?>" class='form-control'>
               <label for="detail">Details</label>
               <input type="text" id="detail" name="detail" value="<?php echo $detail;?>" class='form-control'>
               <label for="qty">Quantite</label>
               <select name="qty" id="qty" class="form-control" onchange="prixChange()">
                 <option value="1">1</option>
                 <option value="2">2</option>
                 <option value="3">3</option>
                 <option value="4">4</option>
                 <option value="5">5</option>
               </select>
               <label class="text-justify">Prix </label>
               <label id="showprix" class='form-control'><?php echo $prix." $";?></label>
               <input type="hidden" id="prix" name="prix" value="<?php echo $prix;?>" class='form-control'>
               <label for="mode">Mode de payment</label><br>
               <input type="checkbox" name="mpesa" value="Mpesa" checked>&nbsp;M-pesa
               <input type="tel" id="mode" name="mpesaNum" placeholder="081*******" class='form-control'>
               <input type="hidden" name="foodid" value="<?php echo $search_menu;?>">
               <input type="submit" name="command" value="Commande" class="btn btn-primary py-3 px-5 mt-2">
             </form>
             <br>
            </div>
          </div>
        </div>
      </div>
    </section>
  <?php }?>
    <!-- End of display command detail information -->

	<!-- Our menu plan -->
    <section class="ftco-section">
      <div class="container">
        <div class="row no-gutters justify-content-center mb-5 pb-2">
          <div class="col-md-12 text-center heading-section ftco-animate">
            <span class="subheading">Spécialités</span>
            <h2 class="mb-4">Notre menu</h2>
          </div>
        </div>
        <div class="row no-gutters d-flex align-items-stretch">
      <?php 
      $sql_menu = "select title,detail,prix,image,foodid from tbl_food";
      $res_menu = mysqli_query($con, $sql_menu);
      while ($row_menu = mysqli_fetch_assoc($res_menu)){?>
          <div class="col-md-12 col-lg-6 d-flex align-self-stretch">
            <div class="menus d-sm-flex ftco-animate align-items-stretch">
              <div class="menu-img img" style="background-image: url(<?php echo $row_menu['image'];?>)"></div>
              <div class="text d-flex align-items-center">
                <div>
                  <div class="d-flex">
                    <div class="one-half">
                      <h3><?php echo $row_menu['title'];?></h3>
                    </div>
                    <div class="one-forth">
                      <span class="price">$<?php echo $row_menu['prix'];?></span>
                    </div>
                  </div>
                  <p><?php echo $row_menu['detail'];?></p>
                  <p><a href="command.php?pay=<?php echo $row_menu['foodid'];?>" class="btn btn-primary">Commandez maintenant</a></p>
                </div>
              </div>
            </div>
          </div>
        <?php }?>
        </div>
      </div>
    </section>
		

    <script type="text/javascript">
      //Increase prix by make changing with the user
      function prixChange(){
      var qty_ = document.getElementById('qty').value;
      var prix = parseInt(<?php echo $prix;?>);
      var qty_num = parseInt(qty_);
      if (qty_num === 1) {
       document.getElementById('prix').value = prix;
       var show =document.getElementById('showprix');
       show.innerText = prix+" $"; 
      }
      if(qty_num === 2)
      {
      num = 2 * prix;
      document.getElementById('prix').value = num;
      var show =document.getElementById('showprix');
       show.innerText = num+" $";        
      }
      if(qty_num === 3)
      {
      num = 3 * prix;
      document.getElementById('prix').value = num;
      var show =document.getElementById('showprix');
       show.innerText = num+" $";        
      }
      if(qty_num === 4)
      {
      num = 4 * prix;
      document.getElementById('prix').value = num;
      var show =document.getElementById('showprix');
       show.innerText = num+" $";        
      }
      if(qty_num == 5)
      {
      num = 5 * prix;
      document.getElementById('prix').value = num;
      var show =document.getElementById('showprix');
       show.innerText = num+" $";        
      }
    }
    </script>
    <?php include_once('footer.php');?>

    <?php 
     if (isset($_POST['command'])) {
       //checking if user is already login
      if ($userlogin != '') {
    //declaration of variable from databases
    $name = mysqli_escape_string($con, $_POST['name']);
    $qty = mysqli_escape_string($con, $_POST['qty']);
    $prix = mysqli_escape_string($con, $_POST['prix']);
    $mode_paymn = mysqli_escape_string($con, $_POST['mpesa']);
    $mode_num = mysqli_escape_string($con, $_POST['mpesaNum']);
    $foodid = mysqli_escape_string($con, $_POST['foodid']);
    //getmonth from user
    $getmonth = date('m');
    $getday = date('d');
    $getyear = date('Y');
    if ($getmonth == 1) {
      $month = 'Jan';
    }
    if ($getmonth == 2) {
      $month = 'Fev';
    }
    if ($getmonth == 3) {
      $month = 'Mars';
    }
    if ($getmonth == 4) {
      $month = 'Avril';
    }
    if ($getmonth == 5) {
      $month = 'Mai';
    }
    if ($getmonth == 6) {
      $month = 'Juin';
    }
    if ($getmonth == 7) {
      $month = 'Juil';
    }
    if ($getmonth == 8) {
      $month = 'Aout';
    }
    if ($getmonth == 9) {
      $month = 'Sept';
    }
    if ($getmonth == 10) {
      $month = 'Oct';
    }
    if ($getmonth == 11) {
      $month = 'Nov';
    }
    if ($getmonth == 12) {
      $month = 'Dec';
    }
    $getdate = $getday." ".$month." ".$getyear;
    $transaction = $name.date('dmY').rand(1000,3000);
    //End of variable declaration
    $sql_command = "insert into tbl_oder(userid,qty,price,date_oder,mode_payment,num_payment,transaction_num,foodid) values('$name','$qty','$prix','$getdate','$mode_paymn','$mode_num','$transaction','$foodid')";
     $res_command = mysqli_query($con, $sql_command);
      if ($res_command) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Merci d\'avoir Commandez dans notre restaurant. Voici votre code $transaction de verification.';
           </script>";
      }       
      }else{
        echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Veuillez d\'abord vous connecter pour Commande la nourriture';
           </script>";
      }
     }

    ?>
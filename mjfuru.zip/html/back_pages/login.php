<?php include_once('header.php');?>    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Se connecter</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>
connecter <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
    <br>
		
		<section class="ftco-section ftco-no-pt ftco-no-pb">
			<div class="container-fluid px-0">
				<div class="row d-flex no-gutters">
          <!-- Signup account configuration -->
          <?php if ($_GET['login'] == 'signup') {?>
          <div class="col-md-6 order-md-last ftco-animate makereservation p-4 p-md-5 pt-5">
          	<div class="py-md-5">
	          <div class="heading-section ftco-animate mb-5">
		          	<span class="subheading">Réserver compte</span>
              <h2 class="mb-4">Inscrivez-vous</h2>
            </div>
            <!-- Error handler -->
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="errorBox">
            <strong id="errorMsg"></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <form action="" method="post" class="p-2" style="border:1px solid lightgray;border-radius: 5px;">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Nom</label>
                    <input type="text" name="name" class="form-control" placeholder="Votre nom">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Mail</label>
                    <input type="email" name="email" class="form-control" placeholder="Votre mail">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Téléphone</label>
                    <input type="text" name="phone" class="form-control" placeholder="Téléphone">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Mot de passe</label>
                    <input type="password" name="password" class="form-control" id="" placeholder="Mot de passe">
                  </div>
                </div>
                <div class="col-md-6 mt-3">
                  <div class="form-group text-center">
                    <input type="submit" value="create un compte" class="btn w-100 btn-primary py-3 px-5" name="signup">
                  </div>
                </div>
                <!-- Want to login -->
                <div class="col-md-6 mt-3">
                  <div class="form-group text-center w-100">
                    <p>Avez-vous un compte ?<a href="login.php?login=signin" class="ml-2"><i class="fas fa-arrow-right" style="font-size: 20px;"></i></a></p>
                  </div>
                </div>
              </div>
            </form>
	          </div>
          </div>
        <?php }?>
        <!-- Signup account configuration -->
          <?php if ($_GET['login'] == 'signin') {?>
          <div class="col-md-6 order-md-last ftco-animate makereservation p-4 p-md-5 pt-5">
            <div class="py-md-5">
            <div class="heading-section ftco-animate mb-5">
                <span class="subheading">Acceder compte</span>
              <h2 class="mb-4">Utilisateur détails</h2>
            </div>
            <!-- Error handler -->
            <div class="alert alert-danger alert-dismissible fade show" role="alert" id="errorBox">
            <strong id="errorMsg"></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <form action="" class="p-2" style="border:1px solid lightgray;border-radius: 5px;" method="post">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                  <label for="">Mail</label>
                    <input type="email" name="email" class="form-control" placeholder="Votre mail">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Mot de passe</label>
                    <input type="password" name="password" class="form-control" placeholder="Votre Mot de passe">
                  </div>
                </div>
                
                
                <div class="col-md-6 mt-3">
                  <div class="form-group text-center">
                    <input type="submit" value="connecter" class="btn w-100 btn-primary py-3 px-5" name="signin">
                  </div>
                </div>
                <!-- Want to login -->
                <div class="col-md-6 mt-3">
                  <div class="form-group text-center w-100">
                    <p>Avez-vous pas un compte ?<a href="login.php?login=signup" class="ml-2"><i class="fas fa-arrow-right" style="font-size: 20px;"></i></a></p>
                  </div>
                </div>
              </div>
            </form>
            </div>
          </div>
        <?php }?>
          <!-- Right logo of the website -->
          <div class="col-md-6 d-flex align-items-stretch pb-5 pb-md-0" style="background: url('images/image_6.jpg');background-size: cover;opacity: 0.9; border-top-right-radius: 5px;border-bottom-right-radius: 5px;">
					</div>
        </div>
			</div>
		</section>
		<br>
    <script>
      element = document.getElementById('login');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
    <?php include_once('footer.php');?>
    <?php 
    if (isset($_POST['signin'])) {
  $user = mysqli_escape_string($con, $_POST['email']);
  $pass = mysqli_escape_string($con, $_POST['password']);
  $hash = md5($pass);
  $sql_user = "select * from tbl_users where email='$user' and passwd='$hash'";
  $res_user = mysqli_query($con, $sql_user) or die('sory');
  if (mysqli_num_rows($res_user) > 0) {
    while ($row_user = mysqli_fetch_assoc($res_user)) {
      session_start();
      $_SESSION['user_mjfuru'] = $row_user['name'];
      echo '<script> window.location = "index.php";</script>';
    }
  }else{
    echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'le nom d\'utilisateur et le mot de passe sont incorrects';
           </script>";
  }

  }

    ?>
    <!-- Checking for signup -->
    <?php

    if (isset($_POST['signup'])) {
    $name = mysqli_escape_string($con, $_POST['name']);
    $email = mysqli_escape_string($con, $_POST['email']);
    $phone = mysqli_escape_string($con, $_POST['phone']);
    $passw = mysqli_escape_string($con, $_POST['password']);
    $date_sign_up = date('Y-m-d');
    $hash = md5($passw);
    //check if user already exist
    $sql_email = "select email from tbl_users where email='$email'";
    $sql_phone = "select phone from tbl_users where phone='$phone'";
    $sql_name = "select name from tbl_users where name='$name'";
    $sql_signup = "insert into tbl_users(name,email,phone,passwd,date_sign_up) values('$name','$email','$phone','$hash','$date_sign_up')";

    $res_email = mysqli_query($con, $sql_email);
    $res_phone = mysqli_query($con, $sql_phone);
    $res_name = mysqli_query($con, $sql_name);
    if (empty($name)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Pardon entre votre nom';
           </script>";
    }
    elseif (empty($email)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Pardon entre votre mail';
           </script>";
    }
    elseif (empty($phone)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Pardon entre votre numero de téléphone';
           </script>";
    }
    elseif (empty($passw)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Pardon entre votre mot de passe';
           </script>";
    }
    elseif (mysqli_num_rows($res_name) > 0) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Nom déjà pris par quelqu\'un';
           </script>";
    }
    elseif (mysqli_num_rows($res_email) > 0) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Mail déjà pris par quelqu\'un';
           </script>";
    }
    elseif (mysqli_num_rows($res_phone) > 0) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Numero déjà pris par quelqu\'un';
           </script>";
    }
    else
    {
    $res_signup = mysqli_query($con, $sql_signup);
    if ($res_signup) {
      session_start();
      $_SESSION['user_mjfuru'] = $name;
      echo '<script> window.location = "index.php";</script>';
    }
    }
    }

    ?>
<?php include_once('header.php');?>    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Bienvenue <?php echo $userlogin;?></h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>
Compte <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
    <!-- Submenu for user access -->
    <div class="container">
      <a href="account.php?home=<?php echo $userlogin;?>">Accuel</a> /
      <a href="account.php?command=<?php echo $userlogin;?>">Commande</a> /
      <a href="account.php?table=<?php echo $userlogin;?>">Table</a> /
      <a href="account.php?logout=<?php echo $userlogin;?>">Se deconnecte</a>
      <br>
      <hr>
  </div>
  <br>
  <?php if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['user_mjfuru']);
  $userlogin = '';
  echo "
   <script>
   window.location = 'index.php';
   </script>
  ";
  }
  ?>

  <?php if (isset($_GET['home'])) {?>
    <!-- End of submenu -->
    <div class="container">
    <div class="row">
		<div class="col-md-4 h-50">
          <div class="card text-center bg-danger text-white mb-3">
            <div class="card-body">
              <h3>Commande</h3>
              <h4 class="display-4">
                <i class="fas fa-utensils"></i> <strong id="post" class="ml-2">
                  <?php 
                  $sql_com = "select count(id) as val from tbl_oder where userid='$userlogin'";
                  $res_com = mysqli_query($con, $sql_com);
                  while($row_com = mysqli_fetch_assoc($res_com)){
                    $cmd_show = $row_com['val'];
                  }
                  echo $cmd_show;
                  ?>

                </strong> 
              </h4>
              <hr>
              <strong><i class="fas fa-sync-alt mr-2"></i>mis à jour maintenant</strong>
            </div>
          </div>
      </div>
      <div class="col-md-4 h-50">
          <div class="card text-center bg-secondary text-white mb-3">
            <div class="card-body">
              <h3>Table</h3>
              <h4 class="display-4">
                <i class="fas fa-table"></i> 
                <strong id="message" class="ml-2">
                  <?php 
                  $sql_com = "select count(id) as val from tbl_reservation where name='$userlogin'";
                  $res_com = mysqli_query($con, $sql_com);
                  while($row_com = mysqli_fetch_assoc($res_com)){
                    $cmd_show = $row_com['val'];
                  }
                  echo $cmd_show;
                  ?>
                </strong>
              </h4>
              <hr>
              <strong><i class="fas fa-sync-alt mr-2"></i>mis à jour maintenant</strong>
            </div>
          </div>
        </div>
        <div class="col-md-4 h-50">
          <div class="card text-center bg-success text-white mb-3">
            <div class="card-body">
              <h3>Cash</h3>
              <h4 class="display-4">
                <i class="fas fa-wallet"></i> <strong id="contact" class="ml-2">
                  <?php 
                  $sql_com = "select sum(price) as val from tbl_oder where userid='$userlogin'";
                  $res_com = mysqli_query($con, $sql_com);
                  while($row_com = mysqli_fetch_assoc($res_com)){
                    $cmd_show = $row_com['val'];
                  }
                  echo $cmd_show."$";
                  ?>
                </strong> 
              </h4>
              <hr>
              <strong><i class="fas fa-sync-alt mr-2"></i>mis à jour maintenant</strong>
            </div>
          </div>
        </div>
		</div>
  </div>
<?php }?>
<?php if (isset($_GET['command'])) {?>
    <!-- End of submenu -->
    <div class="container">
    <div class="row">
    <h2 class="mb-2">Votre commandez</h2>
    <br>
    <table class="table table-hover">
        <tr>
        <th>Image</th>
        <th>Details</th>
        <th>Qty</th>
        <th>Prix</th>
        <th>TransactionId</th>
      </tr>
    <?php
    $dateToday = date('Y-m-d');
    $sql_oder = "select * from tbl_oder where userid='$userlogin' and date_oder = '$dateToday'";
      $res_oder = mysqli_query($con, $sql_oder);
      while ($row_oder = mysqli_fetch_assoc($res_oder)) {
      $foodid = $row_oder['foodid'];
      ?>
      <tr>
      <td>
      <?php 
      $sql_food = "select * from tbl_food where foodid='$foodid'";
      $res_food = mysqli_query($con, $sql_food);
      while ($row_food = mysqli_fetch_assoc($res_food)) {
       $foodimg = $row_food['image'];
       $fooddtl = $row_food['detail'];
       } 
      ?>
      <img src="<?php echo $foodimg;?>" width="70" height="70" style="border-radius: 5px;">
      </td>
      <td><?php echo $fooddtl;?></td>
      <td><?php echo $row_oder['qty'];?></td>
      <td><?php echo $row_oder['price']." $";?></td>
      <td><?php echo $row_oder['transaction_num'];?></td>
    </tr>
      <?php }?>
      </table>
    </div>
  </div>
<?php }?>
<?php if (isset($_GET['table'])) {?>
    <!-- End of submenu -->
    <div class="container">
    <div class="row">
    <h2 class="mb-2">Réservation de table</h2>
    <br>
    <table class="table table-hover">
        <tr>
        <th>Name</th>
        <th>Phone</th>
        <th>Date</th>
        <th>Heure</th>
        <th>Nombre de table</th>
      </tr>
    <?php
    $dateToday = date('Y-m-d');
    $sql_tbl = "select * from tbl_reservation where name='$userlogin' and date_book >= '$dateToday'";
      $res_tbl = mysqli_query($con, $sql_tbl);
      while ($row_tbl = mysqli_fetch_assoc($res_tbl)) {?>
      <tr>
      <td><?php echo $row_tbl['name'];?></td>
      <td><?php echo $row_tbl['phone'];?></td>
      <td><?php echo $row_tbl['date_book'];?></td>
      <td><?php echo $row_tbl['heure_book'];?></td>
      <td><?php echo $row_tbl['number_of_table'];?></td>
    </tr>
      <?php }?>
      </table>
    </div>
  </div>
<?php }?>
  <div style="width: 100%;height: 260px;">
    
  </div>
  <script>
      element = document.getElementById('login');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
    <?php include_once('footer.php');?>
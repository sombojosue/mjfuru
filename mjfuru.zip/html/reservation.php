<?php include_once('header.php');?>    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/table_01.jpg');background-size:cover;" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Réserver une table</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>
Réservation <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		<section class="ftco-section ftco-no-pt ftco-no-pb">
			<div class="container-fluid px-0">
				<div class="row d-flex no-gutters">
          <div class="col-md-6 order-md-last ftco-animate makereservation p-4 p-md-5 pt-5">
          	<div class="py-md-5">
	          	<div class="heading-section ftco-animate mb-5">
		     <span class="subheading" id="hide-table">Réserver une table</span><br>
              <h2 class="mb-4">Faire une réservation</h2>
            </div>
            <!-- Error handler -->
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="errorBox">
            <strong id="errorMsg"></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <form action="" method="post" autocomplete="off">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Nom</label>
                    <input type="text" name="name" class="form-control" placeholder="Votre nom" required >
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Mail</label>
                    <input type="email" name="email" class="form-control" placeholder="Votre mail"  required >
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Téléphone</label>
                    <input type="tel" name="phone" class="form-control" placeholder="Téléphone" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Date</label>
                    <input type="text" class="form-control" id="date_pick" placeholder="jj / mm / aaaa" name="date" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Heure</label>
                    <input type="text" class="form-control" id="time_pick" name="heure" placeholder="Heure" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Table</label>
                    <div class="select-wrap one-third">
                      <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                      <select name="table" id="" class="form-control">
                        <option value="">choisis le nombre de table</option>
                        <option value="2">à 2</option>
                        <option value="3">à 3</option>
                        <option value="4">à 4</option>
                        <option value="5">à 5</option>
                        <option value="6">à 6</option>
                        <option value="7">à 7</option>
                        <option value="8">à 8</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 mt-3">
                  <div class="form-group text-center">
                    <input type="submit" name="reserve" value="Faire une réservation" class="btn color-picker py-3 px-5">
                  </div>
                </div>
              </div>
            </form>
	          </div>
          </div>
          <div class="col-md-6 d-flex align-items-stretch pb-5 pb-md-0">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.3576913034394!2d15.282525714761029!3d-4.343794896842864!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1a6a3179a26a6c93%3A0x543a1d8b01aba338!2sMJFuru%20restaurant!5e0!3m2!1sen!2scd!4v1601364547247!5m2!1sen!2scd" width="700" height="610" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
					</div>
        </div>
			</div>
		</section>
		
    <?php include_once('footer.php');?>

          <?php

    if (isset($_POST['reserve'])) {
    $name = mysqli_escape_string($con, $_POST['name']);
    $email = mysqli_escape_string($con, $_POST['email']);
    $phone = mysqli_escape_string($con, $_POST['phone']);
    $date_res = mysqli_escape_string($con, $_POST['date']);
    $heure = mysqli_escape_string($con, $_POST['heure']);
    $table_res = mysqli_escape_string($con, $_POST['table']);
    $datetocheck = date('Y-m-d');

    $sql_table = "insert into tbl_reservation(name,email,phone,date_book,heure_book,number_of_table) values('$name','$email','$phone','$date_res','$heure','$table_res')";

    
    if (empty($name)) {
      echo "
           <script>
           window.location = 'reservation.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre nom';
           </script>";
    }
    elseif (empty($email)) {
      echo "
           <script>
           window.location = 'reservation.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre mail';
           </script>";
    }
    elseif (empty($phone)) {
      echo "
           <script>
           window.location = 'reservation.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre numéro de téléphone';
           </script>";
    }
    elseif (empty($heure)) {
      echo "
           <script>
           window.location = 'reservation.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre heure de réservation';
           </script>";
    }
    elseif (empty($table_res)) {
      echo "
           <script>
           window.location = 'reservation.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez le nombre de table';
           </script>";
    }
    
    elseif (empty($date_res)) {
      echo "
           <script>
           window.location = 'reservation.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez la date';
           </script>";
    }
    else
    {
    $res_table = mysqli_query($con, $sql_table);
    if ($res_table) {
      echo "
           <script>
           window.location = 'reservation.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Votre réservation est enregistrée';
           </script>";

    }
    }
    }

    ?>
    
  

    <?php
    if(isset($res_table)){

    include('includes/sendmail.php');
    }
    ?>

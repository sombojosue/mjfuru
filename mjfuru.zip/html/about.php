<?php include_once('header.php');?>    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/about.jpg');background-size:cover;" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">A propos</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>À propos <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>


		<section class="ftco-section ftco-wrap-about">
			<div class="container">
				<div class="row">
					<div class="col-md-7 d-flex">
						<div class="img img-1 mr-md-2" style="background-image: url(images/about_01.jpg);"></div>
						<div class="img img-2 ml-md-2" style="background-image: url(images/about_02.png);"></div>
					</div>
					<div class="col-md-5 wrap-about pt-5 pt-md-5 pb-md-3 ftco-animate">
	          <div class="heading-section mb-4 my-5 my-md-0">
	          	<span class="subheading">À propos</span><br>
	            <h2 class="mb-4">MJFuru Restaurant</h2>
	          </div>
	          <p class="text-justify">Situé au Shopping Mall Oasis, sur 9521 avenue Kasa-Vubu, à 15 mètres de la station Moulaert dans la commune Bandalungwa, ville de Kinshasa, RDCongo, MJFuru Restaurant accueille vos papilles avec les plus beaux délices.  Cadre idyllique au cœur de la capitale dans la commune urbaine la plus sympathique, MJFuru Restaurant vous offre un service excellent à un prix plus qu’abordable. Chaque jour, vous êtes notre invité spécial de 7 h 30’ à 24 h 00’. <br>
Pour vos cérémonies, retrouvailles, rencontres entre amis ou amoureux, célébrations d’anniversaire et réunions professionnelles, MJFuru Restaurant est votre choix naturel. Wifi gratuit, écran géant, parking sécurisé et photographe à plein temps, tout est mis en place pour votre plus grande joie.  
</p>
						<pc class="time">
							<span>Lun - Dim <strong>07h30 - 24h00</strong></span>
							<span><a href="tel:+243899958077" style="color:#df3d16" >+ 243 899958077</a></span>
						</p>
					</div>
				</div>
			</div>
		</section>

		
		<section class="ftco-section ftco-counter img ftco-no-pt" id="section-counter">
    	<div class="container">
    		<div class="row d-md-flex">
    			<div class="col-md-9">
    				<div class="row d-md-flex align-items-center">
		          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		              <div class="text">
		                <strong class="number" data-number="10" style="color:#df3d16">0</strong>
		                <span>Années d'expérience</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		              <div class="text">
		                <strong class="number" data-number="50" style="color:df3d16 !important;">0</strong>
		                <span>Menu/Plat</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		              <div class="text">
<strong class="number" data-number="20" style="color:df3d16 !important">0</strong>
		                <span>Personnel</span>
		              </div>
		            </div>
		          </div>
		          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0 d-flex justify-content-center counter-wrap ftco-animate">
		            <div class="block-18">
		              <div class="text">
		                <strong class="number" data-number="150" style="color:#df3d16;">0</strong>
		                <span>Clients satisfaits</span>
		              </div>
		            </div>
		          </div>
	          </div>
          </div>
          <div class="col-md-3 text-center text-md-left">
          	<p>9521 avenue Kasa-Vubu, commune de Bandalungwa au Shopping Mall Oasis, en diagonal de la station Moulaert, non loin de la cité Oasis. </p>
          </div>
        </div>
    	</div>
    </section>

		<section class="ftco-section bg-light">
			<div class="container">
				<div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-12 text-center heading-section ftco-animate">
          	<span class="subheading">Services</span>
            <h2 class="mb-4">Service de restauration</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
            <div class="media block-6 services d-block">
              <div class="icon d-flex justify-content-center align-items-center">
            		<span class="flaticon-cake" style="color:#df0100;"></span>
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Fête <br>d'anniversaire</h3>
              </div>
            </div>      
          </div>
          <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
            <div class="media block-6 services d-block">
              <div class="icon d-flex justify-content-center align-items-center">
            		<span class="flaticon-meeting" style="color:#df0100;"></span>
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Rencontres<br> professionnelles</h3>
              </div>
            </div>    
          </div>
          <div class="col-md-4 d-flex align-self-stretch ftco-animate text-center">
            <div class="media block-6 services d-block">
              <div class="icon d-flex justify-content-center align-items-center">
            		<span class="flaticon-tray" style="color:#df0100;"></span>
              </div>
              <div class="media-body p-2 mt-3">
                <h3 class="heading">Mariage civil <br>ou religieux</h3>
              </div>
            </div>      
          </div>
        </div>
			</div>
		</section>
  
		<section class="ftco-section img" style="background-image: url(images/table_01.jpg)" data-stellar-background-ratio="0.5" id="reservation">
      <div class="container">
        <div class="row d-flex">
          <div class="col-md-7 ftco-animate makereservation p-4 px-md-5 pb-md-5">
            <div class="heading-section ftco-animate mb-5 text-center">
           
              <h2 class="mb-4">Faire une réservation</h2>
            </div>

            <!-- Error handler -->
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="errorBox">
            <strong id="errorMsg"></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <form action="" method="post" autocomplete="off">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Nom</label>
                    <input type="text" name="name" class="form-control" placeholder="Votre nom" required >
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Mail</label>
                    <input type="email" name="email" class="form-control" placeholder="Votre mail"  required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Téléphone</label>
                    <input type="tel" name="phone" class="form-control" placeholder="Téléphone" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Date</label>
                    <input type="text" class="form-control" id="date_pick" placeholder="jj / mm / aaaa" name="date" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Heure</label>
                    <input type="text" class="form-control" id="time_pick" name="heure" placeholder="Heure" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="">Table</label>
                    <div class="select-wrap one-third">
                      <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                      <select name="table" id="" class="form-control">
                        <option value="">choisis le nombre de table</option>
                        <option value="2">à 2</option>
                        <option value="3">à 3</option>
                        <option value="4">à 4</option>
                        <option value="5">à 5</option>
                        <option value="6">à 6</option>
                        <option value="7">à 7</option>
                        <option value="8">à 8</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 mt-3">
                  <div class="form-group text-center">
                    <input type="submit" name="reserve" value="Faire une réservation" class="btn color-picker py-3 px-5">
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>


  <section class="ftco-section testimony-section">
     
      <div class="container">
        <div class="row justify-content-center mb-5">
        <div class="col-xs-12 col-sm-12 col-md-12">
       <div class="heading-section ftco-animate mb-5 text-center">
        <h2 class="mb-4">Visitez-nous</h2>
        <hr style="width:40%;">
     
          <div class="gal-img">
           

           <a href="images/section_02.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_02.jpg" width="250" height="250"></a>

           <a href="images/section_03.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_03.jpg" width="250" height="250"></a>

           <a href="images/section_04.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_04.jpg" width="250" height="250"></a>

           <a href="images/section_05.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_05.jpg" width="250" height="250"></a>

           <a href="images/section_06.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_06.jpg" width="250" height="250"></a>

           <a href="images/section_07.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_07.jpg" width="250" height="250"></a>

           <a href="images/section_08.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_08.jpg" width="250" height="250"></a>

           <a href="images/section_09.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_09.jpg" width="250" height="250"></a>

           <a href="images/section_10.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_10.jpg" width="250" height="250"></a>

           <a href="images/section_11.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_11.jpg" width="250" height="250"></a>

           <a href="images/section_12.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_12.jpg" width="250" height="250"></a>

           <a href="images/section_13.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_13.jpg" width="250" height="250"></a>

           <a href="images/section_14.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_14.jpg" width="250" height="250"></a>

           <a href="images/section_15.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_15.jpg" width="250" height="250"></a>

           <a href="images/section_16.jpg" data-lightbox="mygallery" data-title="Mjfuru Restaurant"><img src="images/section_16.jpg" width="250" height="250"></a>          

          </div>
        </div>
      </div>
     </div>
     </div>
</section>





		<!--
		<section class="ftco-section testimony-section img">
			<div class="overlay"></div>
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-12 text-center heading-section ftco-animate">
          	<span class="subheading">Testimony</span>
            <h2 class="mb-4">Happy Customer</h2>
          </div>
        </div>
        <div class="row ftco-animate justify-content-center">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel ftco-owl">
              <div class="item">
                <div class="testimony-wrap text-center pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/person_1.jpg)">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text p-3">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    <p class="name">Jason McClean</p>
                    <span class="position">Customer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/person_2.jpg)">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text p-3">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    <p class="name">Mark Stevenson</p>
                    <span class="position">Customer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/person_3.jpg)">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text p-3">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    <p class="name">Art Leonard</p>
                    <span class="position">Customer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/person_4.jpg)">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text p-3">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    <p class="name">Rose Henderson</p>
                    <span class="position">Customer</span>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap text-center pb-5">
                  <div class="user-img mb-4" style="background-image: url(images/person_3.jpg)">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text p-3">
                    <p class="mb-4">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
                    <p class="name">Ian Boner</p>
                    <span class="position">Customer</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
		-->
    <script>
      element = document.getElementById('about');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
    <?php include_once('footer.php');?>

      <?php

    if (isset($_POST['reserve'])) {
    $name = mysqli_escape_string($con, $_POST['name']);
    $email = mysqli_escape_string($con, $_POST['email']);
    $phone = mysqli_escape_string($con, $_POST['phone']);
    $date_res = mysqli_escape_string($con, $_POST['date']);
    $heure = mysqli_escape_string($con, $_POST['heure']);
    $table_res = mysqli_escape_string($con, $_POST['table']);
    $datetocheck = date('Y-m-d');

    $sql_table = "insert into tbl_reservation(name,email,phone,date_book,heure_book,number_of_table) values('$name','$email','$phone','$date_res','$heure','$table_res')";

    
    if (empty($name)) {
      echo "
           <script>
           window.location = 'about.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre nom';
           </script>";
    }
    elseif (empty($email)) {
      echo "
           <script>
           window.location = 'about.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre mail';
           </script>";
    }
    elseif (empty($phone)) {
      echo "
           <script>
           window.location = 'about.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre numéro de téléphone';
           </script>";
    }
    elseif (empty($heure)) {
      echo "
           <script>
           window.location = 'about.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre heure de réservation';
           </script>";
    }
    elseif (empty($table_res)) {
      echo "
           <script>
           window.location = 'about.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez le nombre de table';
           </script>";
    }
    
    elseif (empty($date_res)) {
      echo "
           <script>
           window.location = 'about.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez la date';
           </script>";
    }
    else
    {
    $res_table = mysqli_query($con, $sql_table);
    if ($res_table) {
      echo "
           <script>
           window.location = 'about.php#reservation';
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Votre réservation est enregistrée';
           </script>";
    }
    }
    }

    ?>

    <?php
    if(isset($res_table)){

    include('includes/sendmail.php');
    }
    ?>


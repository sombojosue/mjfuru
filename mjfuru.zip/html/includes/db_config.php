<?php

//create user information to login into the database

$userAccount = 'josue';
$passAccount = 'josbeby@1993';
$host = 'localhost';
$db_name = 'mjfuru_db';

$con = mysqli_connect($host, $userAccount, $passAccount, $db_name);
?>

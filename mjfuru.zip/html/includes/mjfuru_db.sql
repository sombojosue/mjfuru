-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2020 at 04:34 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mjfuru_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog`
--

CREATE TABLE `tbl_blog` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_blog`
--

INSERT INTO `tbl_blog` (`id`, `image`) VALUES
(1, 'images/blog_1.jpg'),
(2, 'images/blog_1.jpg'),
(3, 'images/blog_1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `message` varchar(255) NOT NULL,
  `contact_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `name`, `email`, `subject`, `message`, `contact_date`) VALUES
(1, 'esther', 'esther@gmail.com', 'mange', 'Je suis tres heureux ma grd soeur', '2020-09-01'),
(2, 'sombo', 'sombo@gmail.com', 'sombo', 'I love you very much my dear system', '2020-09-01'),
(3, 'sombo', 'sombo@gmail.com', 'sombo', 'I love you very much my dear system', '2020-09-01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `detail` varchar(30) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `detail`, `image`) VALUES
(1, 'Burger', 'Poulet Burger', 'images/burger_poulet.jpg'),
(2, 'Burger', 'Viande Burger ', 'images/burger_viande.jpg'),
(3, 'Burger', 'Cheese Burger ', 'images/cheese_burger.jpg'),
(4, 'Burger', 'Double Burger ', 'images/double-burger.jpg'),
(5, 'Pizza', 'Pizza Anchois', 'images/pizza_anchois.jpeg'),
(6, 'Pizza', 'Pizza Crevette', 'images/pizza_crevette.jpg'),
(7, 'Chawarma', 'Chawarma', 'images/chawarma_01.jpg'),
(8, 'Chawarma', 'Chawarma', 'images/chawarma_02.jpg'),
(9, 'Chawarma', 'Chawarma', 'images/chawarma_03.jpg'),
(10, 'Chawarma', 'Chawarma', 'images/chawarma_04.jpg'),
(11, 'Sandwich', 'Sandwich', 'images/sandwich_01.jpg'),
(12, 'Sandwich', 'Sandwich', 'images/sandwich_02.jpg'),
(13, 'Sandwich', 'Sandwich', 'images/sandwich_03.jpg'),
(14, 'Sandwich', 'Sandwich', 'images/sandwich_04.jpg'),
(15, 'Salade', 'Salade Cesar Poulet', 'images/salade_cesar_poulet.jpeg'),
(16, 'Salade', 'Salade Choux Mayonnaise', 'images/salade_choux_mayonnaise.jpg'),
(17, 'Salade', 'Salade Grec', 'images/salade_grec.jpg'),
(18, 'Milkshake', 'Fruits', 'images/milkshake.jpg'),
(19, 'Omelette', 'Omelette Champignons', 'images/omelette_champignons.jpg'),
(20, 'Omelette', 'Omelette Fromage', 'images/Omelette_fromage.jpg'),
(21, 'Omelette', 'Omelette Nature', 'images/omelette_nature.jpg'),
(22, 'Chicken', 'chicken Combo', 'images/chicken_combo.jpg'),
(23, 'Boisson', 'Maltina', 'images/maltina.jpg'),
(24, 'Boisson', 'Red bull', 'images/red_bull.jpg'),
(25, 'Boisson', 'Castel', 'images/castel.png'),
(26, 'Boisson', 'Heineken', 'images/heineken.jpg'),
(27, 'Boisson', 'Legend', 'images/legend.jpg'),
(28, 'Boisson', 'Mutzig', 'images/mutzig.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_newsletter`
--

CREATE TABLE `tbl_newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_newsletter`
--

INSERT INTO `tbl_newsletter` (`id`, `email`) VALUES
(1, 'esther@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reservation`
--

CREATE TABLE `tbl_reservation` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(15) NOT NULL,
  `date_book` varchar(20) DEFAULT NULL,
  `heure_book` varchar(30) DEFAULT NULL,
  `number_of_table` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_reservation`
--

INSERT INTO `tbl_reservation` (`id`, `name`, `email`, `phone`, `date_book`, `heure_book`, `number_of_table`) VALUES
(1, 'esther', 'esther@gmail.com', '987654321', '2020-12-22', '1:30am', '6'),
(2, 'esther', 'esther@gmail.com', '987654321', '2020-12-22', '1:30am', '6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_newsletter`
--
ALTER TABLE `tbl_newsletter`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reservation`
--
ALTER TABLE `tbl_reservation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_blog`
--
ALTER TABLE `tbl_blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_newsletter`
--
ALTER TABLE `tbl_newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_reservation`
--
ALTER TABLE `tbl_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start(); 
//include db_config file
include_once('includes/db_config.php');

?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <title>MJFuru Restaurant</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="css/jquery-ui.min.css">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
   
   <!-- Favicon -->
   <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
   <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.ico">
   <link rel="manifest" href="images/site.webmanifest">
    <!-- End of favicon -->
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- fontawesome -->
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="css/lightbox.min.css">
  <style>
    #header{
     height: 60px;
     border-bottom: 1px solid red;
    }
    #logo-style{
      width: 50px;
      height: 50px;
      border-radius: 50px;
      margin-top: 5px;
      margin-left: 10%;
    }
  </style>
</head>
<body>
<header id="header" class="container-fluid" style="background-color:#df0100;">
 <div class="row">
   <div class="col-sm-12 col-md-6">
     <img alt="mgfuru logo" src="images/android-chrome-192x192.png" id="logo-style">
   </div>
    <div class="col-sm-12 col-md-6">
     <h3 style="float: right;margin-right: 10%;margin-top: 10px;"><a href="index.php"><i class="fas fa-home text-white"></i></a></h3>
   </div>
 </div> 
</header>

<section class="container-fluid">
  <div class="row">
    <div class="col-xs-12 col-sm-12  col-md-5 order-md-last ftco-animate makereservation p-4 p-md-5 pt-5" style="margin: 0 auto;">
           <br>
           <br>
           <br>
            <form action="" class="p-2" style="border:1px solid lightgray;border-radius: 5px;" method="post">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                  <label for="">Mail</label>
                    <input type="email" name="email" class="form-control" placeholder="Votre mail">
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label for="">Mot de passe</label>
                    <input type="password" name="password" class="form-control" placeholder="Votre Mot de passe">
                  </div>
                </div>
                <div class="col-md-12 mt-3">
                  <div class="form-group text-center">
                    <input type="submit" value="connecter" style="background-color:#df0100;color:#fff;"  class="btn w-100 py-2 px-2" name="signin">
                  </div>
                </div>
              </div>
            </form>
            </div>
  </div>
</section>

<?php include_once('footer.php');?>

<?php 
    if (isset($_POST['signin'])) {
  $user = mysqli_escape_string($con, $_POST['email']);
  $pass = mysqli_escape_string($con, $_POST['password']);
  $sql_user = "select * from tbl_user where email='$user' and passwd='$pass'";
  $res_user = mysqli_query($con, $sql_user) or die('sory');
  if (mysqli_num_rows($res_user) > 0) {
    while ($row_user = mysqli_fetch_assoc($res_user)) {
      session_start();
      $_SESSION['user_mjfuru'] = $row_user['email'];
      echo '<script> window.location = "checktable.php?q=search";</script>';
    }
  }else{
    echo "
           <script>
           alert('Votre compte n\'existe pas dans notre systeme');
           </script>";
  }

  }

    ?>

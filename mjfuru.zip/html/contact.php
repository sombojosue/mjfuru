<?php include_once('header.php');?>    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/contact.jpg');background-size:cover;" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Contact</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Nous contacter <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		
		<section class="ftco-section ftco-no-pt ftco-no-pb contact-section" id="show">
			<div class="container">
				<div class="row d-flex align-items-stretch no-gutters">
					<div class="col-md-6 pt-5 px-2 pb-2 p-md-5 order-md-last">
						<h2 class="h4 mb-2 mb-md-5 font-weight-bold">Contactez-nous</h2>
            <!-- Error handler -->
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="errorBox">
            <strong id="errorMsg"></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
						<form action="" method="post">
              <div class="form-group">
                <input type="text" name="name" class="form-control" placeholder="Votre Nom" required>
              </div>
              <div class="form-group">
                <input type="email" name="email" required class="form-control" placeholder="Votre Mail">
              </div>
              <div class="form-group">
                <input type="text" name="subject" class="form-control" placeholder="Sujet" required>
              </div>
              <div class="form-group">
                <textarea name="message" id="" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
              </div>
              <div class="form-group">
                <input type="submit" name="contact" value="Envoyer" class="btn color-picker py-3 px-5">
              </div>
            </form>
					</div>
					<div class="col-md-6 d-flex align-items-stretch">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.3576913034394!2d15.282525714761029!3d-4.343794896842864!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1a6a3179a26a6c93%3A0x543a1d8b01aba338!2sMJFuru%20restaurant!5e0!3m2!1sen!2scd!4v1601364547247!5m2!1sen!2scd" width="700" height="610" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
					</div>
				</div>
			</div>
		</section>
		<section class="ftco-section contact-section">
      <div class="container">
        <div class="row d-flex contact-info">
          <div class="col-md-12 mb-4">
            <h2 class="h4 font-weight-bold">Contact Information</h2>
          </div>
          <div class="w-100"></div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Address:</span> 9521 avenue Kasa-Vubu, commune de Bandalungwa au Shopping Mall Oasis, en diagonal de la station Moulaert, non loin de la cité Oasis.</p>
            </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Phone:</span> <a href="tel://+243 899958077" style="color: #df0100 !important;">+ 243 899958077</a></p>
            </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Email:</span> <a href="mailto:mjfururestaurant@gmail.com" style="color: #df0100 !important;"><i class="fas fa-envelope"></i> mjfururestaurant@gmail.com</a></p>
            </div>
          </div>
          <div class="col-md-3 d-flex">
          	<div class="dbox">
	            <p><span>Website</span> <a href="index.php" style="color: #df0100 !important;">www.mjfururesto.com</a></p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <script>
      element = document.getElementById('contact');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
		
    <?php include_once('footer.php');?>
    <!-- Checking for signup -->
    <?php

    if (isset($_POST['contact'])) {
    $name = mysqli_escape_string($con, $_POST['name']);
    $email = mysqli_escape_string($con, $_POST['email']);
    $subject = mysqli_escape_string($con, $_POST['subject']);
    $message = mysqli_escape_string($con, $_POST['message']);
    $date_contact = date('Y-m-d');
    

    $sql_contact = "insert into tbl_contact(name,email,subject,message,contact_date) values('$name','$email','$subject','$message','$date_contact')";
    
    if (empty($name)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre nom';
           window.location = 'contact.php#show';
           </script>";
    }
    elseif (empty($email)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre mail';
           window.location = 'contact.php#show';
           </script>";
    }
    elseif (empty($subject)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre sujet';
           window.location = 'contact.php#show';
           </script>";
    }
    elseif (empty($message)) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Entrez votre message';
           window.location = 'contact.php#show';
           </script>";
    }
    else
    {
    $res_contact = mysqli_query($con, $sql_contact);
    if ($res_contact) {
      echo "
           <script>
           var errorbox = document.getElementById('errorBox');
           var errormsg = document.getElementById('errorMsg');
           errorbox.style.display = 'block';
           errormsg.innerText = 'Merci de nous avoir contacté';
           window.location = 'contact.php#show';
           </script>";
    }
    }
    }

    ?>
     <?php 
     if(isset($res_contact)){
      include("includes/contact.php");
     }
     ?>

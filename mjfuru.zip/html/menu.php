<?php include_once('header.php');?>    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/home_01.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate text-center mb-4">
            <h1 class="mb-2 bread">Menu</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Menu <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
	
    
		<!-- Our menu plan -->
    
    <section class="ftco-section">
     <div class="container">
      <div class="row no-gutters justify-content-center mb-5 pb-2">
          <div class="col-md-12 text-center heading-section ftco-animate">
            <span class="subheading">Spécialités</span>
            <h2 class="mb-4">Notre menu</h2>
          </div>
        </div>
      <!-- Menu detail here -->
      <div class="row no-gutters justify-content-left mb-5 pb-2">
        <!-- Menu first -->
        <div class="col-xs-12 col-sm-12 col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #f77b07;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff;">Petit déjeuner</h3>
          </div>
          <div class="body-menu dejeune" style="background-image: url(images/menu1.jpg) !important;border-bottom: 8px solid #f77b07;">
            <div class="text-menu">
             <div style="width: 90%;margin:auto;">
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Petit déjeuner<span style="float: right;"><strong>8.000fc</strong></span></p>
             <p>(Thé ou Café au lait, croissant, pain, confiture)</p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Petit déjeuner <br>continental<span style="float: right;"><strong>11.000fc</strong></span></p>
             <p>(Thé ou Cafe au lait, croissant, Omelette Nature,pain, confiture)</p>
             <hr style="background-color: rgba(0,0,0,.4);">
            </div>
          </div>
            <div class="img-menu">
              <img src="images/dejeun.jpg" class="plat-img">
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu first -->
        <!-- Menu second -->
        <div class="col-xs-12 col-sm-12 col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #fb7907;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff !important;">Omelette</h3>
          </div>
          <div class="body-menu" style="background-image: url(images/menu1.jpg) !important;border-bottom: 8px solid #fb7907">
            <div class="text-menu">
             <div style="width: 90%;margin:auto;">
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Omelette <br>champignon<span style="float: right;"><strong>5.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Omelette fromage<span style="float: right;"><strong>5.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Omelette Nature<span style="float: right;"><strong>4.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Omelette a la <br>viande<span style="float: right;"><strong>7.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <div style="width: 50%;float: left;">
               <img src="images/omelete4.jpg" style="width: 100%;height: 125px;">
             </div>
             <div style="width: 50%;float: left;">
               <img src="images/omelete1.jpg" style="width: 100%;height: 125px;">
             </div>
            </div>
          </div>
            <div class="img-menu">
              <img src="images/omelete2.jpg" style="width: 75%;height: 160px;margin-top: 14px;margin-bottom: 5px;">
              <img src="images/omelete.jpg" style="width: 75%;height: 160px;">
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu second -->  
      </div>

      <!-- Start of third and fouth menu  -->
        <div class="row no-gutters justify-content-left mb-5 pb-2">
        <!-- Menu Third -->
        <div class="col-xs-12 col-sm-12 col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-image: linear-gradient(to right, #491337, #461a27);">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff;">Sandwich</h3>
          </div>
          <div class="body-menu sandwich" style="background-image: url(images/menu1.jpg) !important;border-bottom: 8px solid #491337">
            <br>
            <br>
            <div class="text-menu">
             <div style="width: 96%;margin-left: 2%;">
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Sandwich Fahita <br>poulet<span style="float: right;"><strong>8.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Sandwich Kafta<span style="float: right;"><strong>8.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Sandwich <br>Philadelphia<span style="float: right;"><strong>9.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Sandwich Steak<span style="float: right;"><strong>8.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Sandwich Steak <br>crème<span style="float: right;"><strong>8.500fc</strong></span>
             <hr style="background-color: rgba(0,0,0,.4);"></p>
            </div>
          </div>
            <div class="img-menu">
              <img src="images/burger2.png" width="180" height="180" style="margin-top: 40px;">
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Third -->
        <!-- Menu Fourth -->
        <div class="col-xs-12 col-sm-12 col-md-6 text-left ftco-animate" style="line-height: 24px;background-image: url(images/food1.png);background-repeat: no-repeat;background-size: cover;">
          <div style="width: 99%;">
          <div class="head-menu" style="border-bottom: none;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff !important;">Sandwish &nbsp;<span style="color: #ebee09;">MJFuru</span></h3>
          </div>
          <div class="body-menu">
            <div class="text-menu" style="width: 63%;height: inherit;float: right;">
              <br><br>
             <div class="mobile-center">
             <div style="width: 90%;margin:auto;color: #fff;">
             <hr style="background-color: rgb(255,255,255);">
             <p class="top-marge">Twist wrap<span style="float: right;"><strong>12.000fc</strong></span></p>
             <hr style="background-color: rgb(255,255,255);">
             <p class="top-marge">Cheeza<span style="float: right;"><strong>17.000fc</strong></span></p>
             <hr style="background-color: rgb(255,255,255);">
             <p class="top-marge">chicken filet <br>combo<span style="float: right;"><strong>15.000fc</strong></span></p>
             <hr style="background-color: rgb(255,255,255);">
             <p class="top-marge">Chicken zinga<span style="float: right;"><strong>15.000fc</strong></span></p>
             <hr style="background-color: rgb(255,255,255);">
           </div>
             <div style="text-align: center;">
               
             </div>
            </div>
          </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Fourth -->  
      </div>
      <!-- End of third and fouth menu -->
      <!-- Start of Fith and sixth menu -->
        <div class="row no-gutters justify-content-left mb-5 pb-2">
        <!-- Menu fith -->
        <div class="col-xs-12 col-sm-12 col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <!-- width: 100%;height:400px;background-image: linear-gradient(rgba(183, 17, 3,.9) 70%, #edefec 30%);color: #fff; -->
          <div style="width: 98.5%;">
          <div class="head-menu" style="border-bottom: none;background-color: rgba(183, 17, 3,.9);">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff;padding-top: 10px;">Chawarma</h3>
          </div>
          <div class="body-menu chawarma" style="z-index: 3 !important;background-image: url(images/chawarma.jpg);background-size: cover;border-bottom: 6px solid rgba(183, 17, 3,.9);color:#fff;">
            <div class="text-menu">
             <div style="width: 90%;margin:auto;">
             <hr style="background-color: rgb(255,255,255);">
             <p class="top-marge">Chawarma Poulet<span style="float: right;"><strong>4.500fc</strong></span></p>
             <hr style="background-color: rgb(255,255,255);">
             <p class="top-marge">Chawarma viande <span style="float: right;"><strong>5.000fc</strong></span></p>
             <hr style="background-color: rgb(255,255,255);">
            </div>
          </div>
            <div class="img-menu">
              
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Fith -->
        <!-- Menu Sixth -->
        <div class="col-xs-12 col-sm-12 col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #339c0c;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff !important;">Salade</h3>
          </div>
          <div class="body-menu salade" style="z-index: 3 !important;background-image: url(images/menu1.jpg);border-bottom: 6px solid #339c0c">
            <div class="text-menu">
             <div style="width: 99%;">
             <br>
             <br>
             <p class="top-marge">Salade Cesar <br>au poulet<span style="float: right;"><strong>14.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Salade Chou <br>mayonnaise<span style="float: right;"><strong>5.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Salade Grecque<span style="float: right;"><strong>12.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Salade Nicoise<span style="float: right;"><strong>14.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Salade Saison<span style="float: right;"><strong>9.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <div class="full" style="width: 48%;height: 120px;float: left;margin-right: 2%;">
               <img src="images/salade3.jpg" style="width: 100%;height: inherit;">
             </div>
             <div class="full" style="width: 48%;height: 120px;float: left;margin-right: 2%;">
               <img src="images/salade8.png" style="width: 100%;height: inherit;">
             </div>
            </div>
          </div>
            <div class="img-menu salade-hide" 
            style="background-image: url('images/salade.jpg') !important;background-size: cover;width: 31%;height: 465px;z-index: 1;margin-left: 9%;border-top-left-radius: 68%;border-bottom-left-radius: 65%;border:7px solid #339c0c;border-right: none;border-bottom: none;border-top: none;">
              
              
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu sixth -->  
      </div>
      <!-- End of Fith and sixth menu -->
      <!-- Start of Seventh and Eighth menu -->
        <div class="row no-gutters justify-content-left mb-5 pb-2">
        <!-- Menu Seventh -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #86321a;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff;">Plat</h3>
          </div>
          <div class="body-menu plat" style="background-image: url(images/menu1.jpg);border-bottom: 6px solid #86321a">
            <br>
            <div class="text-menu">
             <div style="width: 96%;margin:auto;">
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Poisson Capitaine<span style="float: right;"><strong>19.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Chicken <br>Burger<span style="float: right;"><strong>10.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Burger <br>a la viande<span style="float: right;"><strong>12.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Shawarma <br>Poulet<span style="float: right;"><strong>15.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Shawarma <br>Viande<span style="float: right;"><strong>16.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat cheese <br>Burger<span style="float: right;"><strong>12.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Classic <br>Burger,<br>+Coca<span style="float: right;"><strong>15.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Double <br>Burger<span style="float: right;"><strong>14.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Fahita <br>Poulet<span style="float: right;"><strong>15.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat filet <br>Poisson Captaine<span style="float: right;"><strong>22.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat filet <br>Poisson<br>Champignon<span style="float: right;"><strong>22.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat filet <br>Poulet<span style="float: right;"><strong>15.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Philadelphia<span style="float: right;"><strong>16.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Steak <br>classic<span style="float: right;"><strong>20.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Plat Steak <br>crème<span style="float: right;"><strong>21.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
            </div>
          </div>
            <div class="img-menu">
              <!-- <img src="images/san.jpg" class="plat-img"> -->
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Seventh -->
        <!-- Menu Eighth -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #280c01;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff !important;">Pizza </h3>
          </div>
          <div class="body-menu pizza" style="background-image: url(images/menu1.jpg);border-bottom: 6px solid #280c01">
            <div class="img-menu">
              <img src="images/pizza1.jpg" style="width: 75%;height: 180px;margin-top: 14px;margin-bottom: 5px;">
              <img src="images/pizza2.jpg" style="width: 75%;height: 180px;">
              <img src="images/pizza3.jpg" style="width: 75%;height: 180px;margin-top: 14px;margin-bottom: 5px;">
              <img src="images/pizza1.jpg" style="width: 75%;height: 180px;">
            </div>
            <div class="text-menu">
              <br><br>
             <div style="width: 90%;margin:auto;">
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Anchois <br>grand<span style="float: right;"><strong>22.000fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Anchois <br>moyen<span style="float: right;"><strong>16.500fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Peperoni <br>moyen<span style="float: right;"><strong>16.500fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Crevette <br>grand<span style="float: right;"><strong>25.000fc</strong></span></p>
             <hr style="background-color: #000;">
             
             
             <p class="top-marge">Pizza Crevette <br>moyen<span style="float: right;"><strong>17.000fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Marguerita <br>grand<span style="float: right;"><strong>18.000fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Marguerita <br>moyen<span style="float: right;"><strong>14.000fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Poulet <br>grand<span style="float: right;"><strong>22.000fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Poulet <br>moyen<span style="float: right;"><strong>25.000fc</strong></span></p>
             <hr style="background-color: #000;">
             
             <p class="top-marge">Pizza Végeteriane <br>grand<span style="float: right;"><strong>19.500fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Végeteriane <br>moyen<span style="float: right;"><strong>14.500fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Viande <br>grand<span style="float: right;"><strong>24.000fc</strong></span></p>
             <hr style="background-color: #000;">
             <p class="top-marge">Pizza Viande <br>moyen<span style="float: right;"><strong>15.500fc</strong></span></p>
             <hr style="background-color: #000;">
            </div>
          </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Eighth -->  
      </div>
      <!-- End of seventh and eighth menu -->

      <!-- Start of nineth and tenth menu -->
        <div class="row no-gutters justify-content-left mb-5 pb-2">
        <!-- Menu Nine -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #040001;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff;">Hamburger</h3>
          </div>
          <div class="body-menu hamburger" style="background-image: url(images/menu1.jpg);border-bottom: 6px solid #040001">
            <br>
            <div class="text-menu">
             <div style="width: 96%;margin:auto;">
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Hamburger Viande<span style="float: right;"><strong>8.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Hamburger Poulet<span style="float: right;"><strong>7.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Hamburger Oeuf<span style="float: right;"><strong>8.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Hamburger <br>Mexicain<span style="float: right;"><strong>8.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Hamburger <br>Classic<span style="float: right;"><strong>8.500fc</strong></span></p>

             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Cheese Burger<span style="float: right;"><strong>9.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Double Burger<span style="float: right;"><strong>11.500fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <div class="">
              <img src="images/burger2.png" width="90" height="90">
              <img src="images/burger5.png" width="100" height="100">
              <img src="images/burger3.png" width="100" height="100">
            </div>
            </div>
          </div>
            <div class="img-menu salade-hide">
              <img src="images/burger2.png" width="170" height="170" style="margin-top: 35%;">
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Nine -->
        <!-- Menu Tenth -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #f5660b;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff !important;">Pasta</h3>
          </div>
          <div class="body-menu pasta" style="background-image: url(images/menu1.jpg);border-bottom: 6px solid #f5660b">
            <div class="img-menu">
              <img src="images/pasta.jpg" style="width: 75%;height: 160px;margin-top: 14px;margin-bottom: 5px;">
              <img src="images/pasta1.jpg" style="width: 75%;height: 160px;margin-bottom: 5px;">
              <img src="images/pasta2.jpg" style="width: 75%;height: 160px;">
            </div>
            <div class="text-menu">
              <br><br>
             <div style="width: 90%;margin:auto;">
             <hr style="background-color: rgb(0,0,0);">
             <p class="top-marge">Spaghetti <br>Bolonaise<span style="float: right;"><strong>11.500fc</strong></span></p>
             <hr style="background-color: rgb(0,0,0);">
             <p class="top-marge">Spaghetti <br>Crevettes<span style="float: right;"><strong>15.500fc</strong></span></p>
             <hr style="background-color: rgb(0,0,0);">
             <p class="top-marge">Carbonara <br>Poulet<span style="float: right;"><strong>13.500fc</strong></span></p>
             <hr style="background-color: rgb(0,0,0);">
             <p class="top-marge">Carbonara <br>Crevette<span style="float: right;"><strong>16.500fc</strong></span></p>
             <hr style="background-color: rgb(0,0,0);">
            
            <p class="top-marge">Rasanes Viande<span style="float: right;"><strong>12.000fc</strong></span></p>
             <hr style="background-color: rgb(0,0,0);">
             <p class="top-marge">Tagliatelle Alfrech <br>Poulet<br> Champigon<span style="float: right;"><strong>13.500fc</strong></span></p>
             <hr style="background-color: rgb(0,0,0);">
             <p class="top-marge">Fahtou Chini<br> Poulet<span style="float: right;"><strong>14.000fc</strong></span></p>
             <hr style="background-color: rgb(0,0,0);">

            </div>
          </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Nine -->  
      </div>
      <!-- End of nineth and tenth menu -->

      <!-- Start of third and fouth menu -->
        <div class="row no-gutters justify-content-left mb-5 pb-2">
        <!-- Menu Eleventh -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #e71312;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 style="color: #fff;">Brosted</h3>
          </div>
          <div class="body-menu brosted" style="border-bottom: 6px solid #e71312">
            <br>
            <div class="text-menu">
             <div style="width: 96%;margin:auto;">
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Familly brosted <br>petit<span style="float: right;"><strong>33.000fc</strong></span></p>
             <p>
               <span>8Pcs poulet + 3Pains</span><br>
               <span>+ 3 Portion de frite</span><br>
               <span>+ 3 Salade + 3coca</span>
             </p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Familly brosted <br>grand<span style="float: right;"><strong>52.000fc</strong></span></p>
             <p>
               <span>16Pcs poulet + 3Pains</span><br>
               <span>+ 4 Portion de frite</span><br>
               <span>+ 4 Salade + 4coca</span>
             </p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Mexic chiken <br>Meal<span style="float: right;"><strong>15.000fc</strong></span></p>
             <p>
               <span>2Pcs poulet + 2Pcs creaspy</span><br>
               <span>+ 1 pain</span><br>
               <span>+ 1 Portion de frite</span><br>
               <span>+ 1 Salade + 1coca</span>
             </p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Ailles de poulet<span style="float: right;"><strong>13.500fc</strong></span></p>
             <p>
               <span>10Pcs ail</span><br>
               <span>+ 1 Pain</span><br>
               <span>+ 1 Portion de frite</span><br>
               <span>+ 1 Salade + 1coca</span>
             </p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Small Combo<span style="float: right;"><strong>8.500fc</strong></span></p>
             <p>
               <span>2Pcs poulet + 1Pains</span><br>
               <span>+ 1 Portion de frite</span><br>
             </p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Medium Combo<span style="float: right;"><strong>14.000fc</strong></span></p>
             <p>
               <span>4Pcs poulet + 1Pains</span><br>
               <span>+ 1 Portion de frite</span><br>
               <span>+ 1 Salade + 1coca</span>
             </p>
             <hr style="background-color: rgba(0,0,0,.4);">
             <p class="top-marge">Mix Chiken<span style="float: right;"><strong>15.000fc</strong></span></p>
             <hr style="background-color: rgba(0,0,0,.4);">
            </div>
          </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Eleventh -->
        <!-- Menu Twelveth -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;background-image: url(images/ruth.jpg);background-size: cover;">
          <div style="width: 98.5%;">
          <div class="head-menu">
            <img class="icon-menu " src="images/icon.jpg">
            <h3 class="marge-left" style="color: #fff !important;">Boisson Sans alcool </h3>
          </div>
          <div class="body-menu sans-alcool" style="border-bottom: 6px solid #e71312">
            
            <div class="text-menu" style="width: 92% !important;margin-left: 8%;">
              <br><br>
             <div class="table-responsive" style="width: 100%;margin:auto;color: #fff;">
             <table class="table text-white">
               <tr style="color: yellow">
                 <th></th>
                 <th>RESTO</th>
                 <th>TERASSE</th>
                 <th>VIP</th>
               </tr>
               <tr>
                 <td>Sucrée bouteille</td>
                 <td>2000</td>
                 <td>1500</td>
                 <td>3000</td>
               </tr>
               <tr>
                 <td>Sucrée canette</td>
                 <td>2500</td>
                 <td>2000</td>
                 <td>3000</td>
               </tr>
               <tr>
                 <td>Eau</td>
                 <td>1000</td>
                 <td>1000</td>
                 <td>1000</td>
               </tr>
               <tr>
                 <td>Maltina</td>
                 <td>2500</td>
                 <td>2000</td>
                 <td>3000</td>
               </tr>
               <tr>
                 <td>RedBull</td>
                 <td>3500</td>
                 <td>3000</td>
                 <td>4000</td>
               </tr>
               <tr>
                 <td>Vitalo</td>
                 <td>2500</td>
                 <td>2000</td>
                 <td>3000</td>
               </tr>
               <tr>
                 <td>Prico</td>
                 <td>2000</td>
                 <td>2000</td>
                 <td>2000</td>
               </tr>
               <tr>
                 <td>Jus Fruits</td>
                 <td>3000</td>
                 <td>3000</td>
                 <td>3000</td>
               </tr>
               <tr>
                 <td>Sucre Plastique</td>
                 <td>1500</td>
                 <td></td>
                 <td></td>
               </tr>
             </table>
            </div>
          </div>
          <div style="width: 100%">
              <!-- Image cola here -->
            </div>
          </div>
          </div> 
        </div>
        <!-- End Menu Twelveth -->  
      </div>

      <!-- End of eleventh and twelveth menu -->
      <!-- Start of 13 and 14 menu -->
        <div class="row no-gutters justify-content-left mb-5 pb-2">
        <!-- Menu 13 -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #000;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 class="marge-left" style="color: #fff;">Cocktail <span style="color: yellow;">avec Alcool</span></h3>
          </div>
          <div class="body-menu cocktail" style="background-image: url(images/menu1.jpg);border-bottom: 6px solid #000">
            
            <div class="text-menu" style="width: 100%;">
             <div class="table-responsive" style="width: 100%;margin:auto;">
             <table class="table">
               <tr style="color: #000;background-color: #a3f628">
                 <th></th>
                 <th>RESTO</th>
                 <th>TERASSE</th>
                 <th>VIP</th>
               </tr>
               <tr>
                 <td>2Saisons</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Arc En-ciel</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Bella Runa</td>
                 <td>5000</td>
                 <td>5000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Blue Ragon</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Cocktail Mixte</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Cocktail Piece</td>
                 <td>7000</td>
                 <td>7000</td>
                 <td>14000</td>
               </tr>
               <tr>
                 <td>Milk Shake</td>
                 <td>9000</td>
                 <td>9000</td>
                 <td>19000</td>
               </tr>
               <tr>
                 <td>MJFuru Fraise</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>MJFuru Juice</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Majito</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>12000</td>
               </tr>
               <tr>
                 <td>Pinacolada</td>
                 <td>15000</td>
                 <td>15000</td>
                 <td>19000</td>
               </tr>
               <tr>
                 <td>Ray Rogers</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>1000</td>
               </tr>
             </table>
             <img src="images/cocktail.jpg" style="width: 100%;height: 180px;border-bottom: 8px solid #000;">
            </div>
          </div>
          </div>
          </div> 
        </div>
        <!-- End Menu 13 -->
        <!-- Menu 14 -->
        <div class="col-md-6 text-left ftco-animate" style="line-height: 24px;">
          <div style="width: 98.5%;">
          <div class="head-menu" style="background-color: #cf930f;">
            <img class="icon-menu" src="images/icon.jpg">
            <h3 class="marge-left" style="color: #fff;">Cocktail <span style="color: yellow;">sans Alcool</span></h3>
          </div>
          <div class="body-menu cocktail" style="background-image: url(images/menu1.jpg);border-bottom: 6px solid #cf930f">
            <div class="text-menu table-responsive" style="width: 100%;">
              <table class="table">
               <tr style="color: #000;background-color: #a3f628">
                 <th></th>
                 <th>RESTO</th>
                 <th>TERASSE</th>
                 <th>VIP</th>
               </tr>
               <tr>
                 <td>2Saisons</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Arc En-ciel</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Bella Runa</td>
                 <td>5000</td>
                 <td>5000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Blue Ragon</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Cocktail Mixte</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Cocktail Piece</td>
                 <td>7000</td>
                 <td>7000</td>
                 <td>14000</td>
               </tr>
               <tr>
                 <td>Milk Shake</td>
                 <td>9000</td>
                 <td>9000</td>
                 <td>19000</td>
               </tr>
               <tr>
                 <td>MJFuru Fraise</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>MJFuru Juice</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>10000</td>
               </tr>
               <tr>
                 <td>Majito</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>12000</td>
               </tr>
               <tr>
                 <td>Pinacolada</td>
                 <td>15000</td>
                 <td>15000</td>
                 <td>19000</td>
               </tr>
               <tr>
                 <td>Ray Rogers</td>
                 <td>6000</td>
                 <td>6000</td>
                 <td>1000</td>
               </tr>
             </table>
             <img src="images/cocktail.jpg" style="width: 100%;height: 180px;border-bottom: 8px solid #cf930f;">
            </div>
          </div>
          </div>
          </div> 
        </div>
        <!-- End Menu 14 -->  
      </div>
      <!-- End of 13 and 14 menu -->
       <!-- End Menu detail here -->         
      </div>
    </section>		
		
    <script>
      element = document.getElementById('menu');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
		
  <?php include_once('footer.php');?>

    

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-53HSJJR"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">MJFuru &nbsp;restaurant</h2>
              <p>Pour vos cérémonies, retrouvailles, rencontres entre amis ou amoureux, célébrations d’anniversaire et réunions professionnelles, MJFuru Restaurant est votre choix naturel. Wifi gratuit, écran géant, parking sécurisé et photographe à plein temps, tout est mis en place pour votre plus grande joie.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="https://twitter.com/mjfuru1"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/mjfurufood"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://pin.it/5TzWaZZ"><span class="icon-pinterest"></span></a></li>
                
                <li class="ftco-animate"><a href="login.php"><span class="icon-table"></span></a></li>
             
              </ul>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Heures d'ouverture</h2>
                     
              <ul class="list-unstyled open-hours">
                <li class="d-flex"><span>Lundi</span><span>07h30 - 24h00</span></li>
                <li class="d-flex"><span>Mardi</span><span>07h30 - 24h00</span></li>
                <li class="d-flex"><span>Mercredi</span><span>07h30 - 24h00</span></li>
                <li class="d-flex"><span>Jeudi</span><span>07h30 - 24h00</span></li>
                <li class="d-flex"><span>Vendredi</span><span>07h30 - 24h00</span></li>
                <li class="d-flex"><span>Samedi</span><span>07h30 - 24h00</span></li>
                <li class="d-flex"><span>Dimanche</span><span>07h30 - 24h00</span></li>
              </ul>
            </div>
          </div>
          
          <div class="col-md-6 col-lg-3">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Facebook</h2>
              <div class="thumb d-sm-flex">
	            	<a href="https://www.facebook.com/mjfuru.furu.5" class="thumb-menu img" style="background-image: url(images/omelete2.jpg);">
	            	</a>
	            	<a href="https://www.facebook.com/mjfuru.furu.5" class="thumb-menu img" style="background-image: url(images/pasta2.jpg);">
	            	</a>
	            	<a href="https://www.facebook.com/mjfuru.furu.5" class="thumb-menu img" style="background-image: url(images/pizza1.jpg);">
	            	</a>
	            </div>
	            <div class="thumb d-flex">
	            	<a href="https://www.facebook.com/mjfuru.furu.5" class="thumb-menu img" style="background-image: url(images/pizza3.jpg);">
	            	</a>
	            	<a href="https://www.facebook.com/mjfuru.furu.5" class="thumb-menu img" style="background-image: url(images/brosted.jpg);">
	            	</a>
	            	<a href="https://www.facebook.com/mjfuru.furu.5" class="thumb-menu img" style="background-image: url(images/salade.jpg);">
	            	</a>
	            </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Bulletin</h2>
            	<p>9521 avenue Kasa-Vubu, commune de Bandalungwa au Shopping Mall Oasis, en diagonal de la station Moulaert, non loin de la cité Oasis.</p>
              <form action="" class="subscribe-form" method="post">
                <div class="form-group">
                  <input type="text" name="email" class="form-control mb-2 text-center" placeholder="Entre mail adresse">
                  <input type="submit" value="s'abonner" class="form-control  px-3" name="newsletter" style="background-color:#df0100 !important;"> 
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> Tous droits réservés au MJFuru restaurant
  </p>
          </div>
        </div>
      </div>
    </footer>
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/lightbox-plus-jquery.min.js"></script>
  <script src="js/jquery-ui.min.js"></script>

  <script src="js/french-lang.js"></script>
  <script src="js/timepicker.js"></script>

  <script>

    $.datepicker.setDefaults( $.datepicker.regional[ "fr" ] );

    $('#date_pick').datepicker({ 
    dateFormat: 'dd-M-yy', 
    minDate: 0,
    maxDate: 30
    });

    $('#time_pick').timepicker({
    timeFormat: 'H:mm',
    interval: 30,
    minTime: '10',
    maxTime: '22:00',
    defaultTime: '9',
    startTime: '10:00',
    dynamic: false,
    dropdown: true,
    scrollbar: true
});

 function changeBack(){

 var img = document.querySelector('#mobile-hide');
    img.style.backgroundImage = "url('images/home_00.jpg')";
    document.querySelector('.mobile-text').innerText = "Le meilleur burger";
}

function changeRight(){

 var img = document.querySelector('#mobile-hide');
    img.style.backgroundImage = "url('images/home_02.jpg')";
    document.querySelector('.mobile-text').innerText = "Delicieux et nutritif";
}

  </script>     
  </body>
</html>

<?php

if (isset($_POST['newsletter'])) {
$email = mysqli_escape_string($con, $_POST['email']);
$sql_email = "select email from tbl_newsletter where email='$email'";
$res_email = mysqli_query($con, $sql_email);
if (empty($email)) {
  echo "
           <script>
           alert('Pardon entre votre mail');
           </script>";
}elseif (mysqli_num_rows($res_email) > 0) {
      echo "
           <script>
           
           alert('Mail déjà enregistre par quelqu\'un');
           </script>";
    }else{
      $sql_news = "insert into tbl_newsletter(email) values('$email')";
      $res_news = mysqli_query($con, $sql_news);
      if ($res_news) {
        echo "
           <script>
           alert('Mail bien enregistré');
           </script>";
      }
    }
}
?>

<?php
session_start(); 
//include db_config file
include_once('includes/db_config.php');

?>
<!DOCTYPE html>
<html lang="fr" prefix="og: https://ogp.me/ns#">
  <head>
    <title>MJFuru Restaurant</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="meilleur restaurant,kinshasa,elubu,buffet,chawarma,rencontre,réunion,mange bien" />
    <meta name="description" content="Manger délicieux chez MJFURU, le meilleur restaurant de Kinshasa. Petit prix, Grands délices !" />
    <meta name="author" content="Josue Sombo Lotshango" />
    <meta property="og:title" content="MJFuru" />
<meta property="og:type" content="website" />
<meta property="og:url" content="https://www.mjfururestau.ga" />
<meta property="og:image" content="https://www.mjfururestau.ga/images/logo192.png" />
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Great+Vibes&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Lobster+Two&family=Playball&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
   
   <!-- Google Tag Manager -->
   <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
   new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
   j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-53HSJJR');</script>


<!-- End Google Tag Manager --> 
   <!-- Global site tag (gtag.js) - Google Analytics -->
   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-179234873-1"></script>
   <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-179234873-1');
    </script>

    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
   <link rel="stylesheet" href="css/timepicker.css">
   <link rel="stylesheet" href="css/jquery-ui.min.css">
   <!-- Favicon -->
   <link rel="apple-touch-icon" sizes="180x180" href="images/apple-touch-icon.png">
   <link rel="icon" type="image/png" sizes="32x32" href="images/favicon-32x32.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png">
   <link rel="icon" type="image/png" sizes="16x16" href="images/logo192.png">
   <link rel="manifest" href="images/site.webmanifest">
    <!-- End of favicon -->
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/lightbox.min.css">
    <!-- fontawesome -->
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
	    <style type="text/css">
        .cta, .cta a{

      color: #fff;

      border: 1px solid #df0100 !important;

      border-radius: 5px;

      background-color: #df0100 !important;

    }

    .active a{

      color: #df0100 !important;

    }

    .subheading{

      color: #df0100 !important;

    }

    .owl-carousel.home-slider .slider-item .slider-text .subheading,mobile-sub {
          font-size: 65px !important;
     }

    .color-picker{

      color: #fff;

     background-color: #df0100 !important; 

    }

    .ftco-navbar-light.scrolled .nav-item.active > a{

      color: #df0100 !important;

    }

    #img-mobile{

        width: 43% !important;

        height: 130px !important;

      }

  	#errorBox{
    		display: none;
    	}
        #mobile-hide{
     display:none !important;
     }
    
     .gal-img{
margin:10px 0 !important;
}

.gal-img img{
transition: 1s;
padding:4px;
width:210px;
height:210px;
}
.gal-img img:hover{
filter:contrast(200%);
transform:scale(1.1);
}
.ftco-counter .text strong.number{
color:#df3d16 !important;
}
/*Menu Design */
    
    .head-menu{
     position: relative;
     width: 100%;
     height: 49px;
     text-align: center;
     border-bottom: 4px rgba(219, 216, 217, .7) solid;
     z-index: 3;
     font-family: 'Playball', cursive;

    }
    .head-menu p{
      font-size: 1.9rem;
      opacity: 1 !important;
    }
    .icon-menu{
      position: absolute;
      top: 0;
      right: 4%;
      height: 50px;
      z-index: 1;
      border-bottom-right-radius: 12px;
      border-bottom-left-radius: 12px;
    }
    .body-menu{
      /* Image goes here for background */
      width: 100%;
      height: 400px;
      font-family: 'Playball', cursive;
    }
    .sandwich{
     height: 450px; 
    }
    .chawarma, .salade{
      height: 470px;
    }
    .salade{
      padding-left: 2%;
    }
    .cocktail{
    width: 100%;
    height: 830px;
    }

    .footer-menu{
      width: 100%;
      height: 120px;
    }
    .body-menu p{
      font-size: 1.4rem;
      letter-spacing: 1px;
      opacity: 1 !important;
    }
    .price{
      float: right;
    }
    table tr td{
      font-size: 1.4rem;
    }
    .text-menu{
      width: 60%;
      float: left;
    }
    .img-menu{
      width: 40%;
      float: left;
      text-align: center;
    }
    .plat{
      width: 100%;
      height: 1080px;
    }
    .pizza{
      width: 100%;
      height: 1080px;
    }
    .hamburger{
      width: 100%;
      height: 570px;
    }
    .pasta{
      width: 100%;
      height: 570px;
    }
    .brosted{
      width: 100%;
      height: 1000px;
      background-image: url(images/poulet.jpg);
    }
    .sans-alcool{
     width: 100%;
     height: 1000px; 
    }
    .plat-img{
      width: 75%;
      height:230px;
      padding-top: 38%;
    }
    .top-marge{
    margin-top: -12px !important;
    }
/*End of Menu Design */

    
  @media only screen and (max-width: 500px) {

     #desk-hide{
     display:none !important;
     }
     #mobile-hide{
      display: block !important;
     }

     .subheading{
       font-family:'Merriweather', serif !important;
       font-size:3rem !important;
      }
     .owl-carousel.home-slider {
    position: relative;
    height: 500px !important;
    z-index: 0; }
     #img-mobile{
     width: 55% !important;
     height: 180px !important;
     }
     #menu-text h3{
     font-size: 2rem !important;
     }
     #menu-text p span{
     font-size: 1.1rem !important;
     }

     #hide-table{
      display:none;
     }
     .gal-img{
     margin:10px 0 !important;
     }
     .gal-img img{
     transition: 1s;
     padding:4px;
     width:320px;
     height:320px;
     }
     .gal-img img:hover{
     filter: grayscale(100%);
     transform:scale(1.1);
     }
   
     /*Menu resize mobile*/ 
     .text-menu{
      width: 100%;
      float: left;
    }
    .img-menu{
      width: 100%;
      float: left;
      text-align: center;
    }
    .body-menu{
      /* Image goes here for background */
      width: 100%;
      height: 740px;
      font-family: 'Playball', cursive;
      margin-bottom: 6px;
    }
    .dejeune{
     height: 550px !important; 
    }

    .chawarma{
     height: 490px !important; 
    }
    .salade{
      height: 650px;
    }
    .sandwich{
     height: 620px !important; 
    }
    .brosted{
      height: 1030px;
      background-image: url('images/menu1.jpg');
    }
    .salade-hide{
      display: none;
    }
    .body-menu p{
      font-size: 1.6rem;
      letter-spacing: 1px;
      opacity: 1 !important;
    }
    .head-menu h3{
      font-size: 2rem;
    }
    .plat-img{
      width: 75%;
      height:230px;
      padding-top: 8%;
    }
    .full{
      width: 100% !important;
      height: 150px !important;
    }
    .plat{
      height: 1120px;
    }
    .pizza{
      height: 1750px;
    }
    .hamburger{
      height: 570px;
    }
    .pasta{
      height: 1130px;
    }
    .mobile-center{
      margin-left: -60%;
      margin-top: 97%;
    }
    .sans-alcool{
     width: 100%;
     height: 700px; 
    }
    .sans-alcool table tr td, .cocktail table tr td{
      font-size: 1.5rem;
    }
    .cocktail{
    width: 100%;
    height: 930px;
    margin-bottom: 8px;
    }

    .marge-left{
      margin-left: -19%;
    }

    /* End of this menu */
     

     }
    </style>
  </head>
  <body>
    <div class="py-1 bg-black top">
    	<div class="container">
    		<div class="row no-gutters d-flex align-items-start align-items-center px-md-0">
	    		<div class="col-lg-12 d-block">
		    		<div class="row d-flex">
		    			<div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
						    <span class="text">+ 243 899958077</span>
					    </div>
					    <div class="col-md pr-4 d-flex topper align-items-center">
					    	<div class="icon mr-2 d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
						    <span class="text">mjfururestaurant@gmail.com</span>
					    </div>
					    <div class="col-md-5 pr-4 d-flex topper align-items-center text-lg-right justify-content-end">
						    <p class="mb-0 register-link"><span>Heures d'ouverture: </span><span>Lundi - Dimanche</span> <span>7h30 à 24h00</span></p>
					    </div>
				    </div>
			    </div>
		    </div>
		  </div>
    </div>
	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">MJFURU</a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	        	<li class="nav-item" id="home"><a href="index.php" class="nav-link">Accueil</a></li>
	        	<li class="nav-item" id="menu"><a href="menu.php" class="nav-link">Menu</a></li>
	        <li class="nav-item" id="about"><a href="about.php" class="nav-link">A propos</a></li>
	        	<li class="nav-item" id="contact"><a href="contact.php" class="nav-link">Contact</a></li>
	          <li class="nav-item cta"><a href="reservation.php" class="nav-link">Réserver une table</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
